# Pancho2.0
Se Incluyo un sistema de reportes que busca el peso mayor que establecido por usuario y saquelo de la carpeta pancho 2.0 y recuerde usar temurin 21

a la hora de declarar decimales no use puntos use comas

