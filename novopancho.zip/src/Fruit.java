import java.io.Serializable;

public class Fruit implements Serializable {
    private static final long serialVersionUID = 1L; // Número de versión para la serialización
    private int id;
    private String name;
    private double weight;
    private double price;

    public Fruit(int id, String name, double weight, double price) {
        this.id = id;
        this.name = name;
        this.weight = weight;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Fruit{id=" + id + ", name='" + name + '\'' + ", weight=" + weight + ", price=" + price + '}';
    }
}