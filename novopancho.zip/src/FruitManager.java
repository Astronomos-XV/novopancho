import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FruitManager {
    private List<Fruit> items;
    private int nextId;

    public FruitManager() {
        items = new ArrayList<>();
        nextId = 1; // Inicializa el ID a partir de 1
        loadFruits(); // Carga frutas al iniciar
    }

    // Método para crear una nueva fruta
    public void createFruit(String name, double weight, double price) {
        Fruit fruit = new Fruit(nextId++, name, weight, price);
        items.add(fruit);
        System.out.println("Fruta creada: " + fruit);
        saveFruits(); // Guardar después de crear
    }

    // Método para leer una fruta específica por ID
    public Fruit readFruit(int id) {
        for (Fruit fruit : items) {
            if (fruit.getId() == id) {
                return fruit;
            }
        }
        return null; // Retorna null si la fruta no se encuentra
    }

    // Método para actualizar una fruta
    public boolean updateFruit(int id, String name, double weight, double price) {
        for (Fruit fruit : items) {
            if (fruit.getId() == id) {
                // Modificar los atributos directamente
                items.remove(fruit);
                createFruit(name, weight, price);
                return true;
            }
        }
        return false; // Retorna false si la fruta no se encuentra
    }

    // Método para eliminar una fruta
    public boolean deleteFruit(int id) {
        for (Fruit fruit : items) {
            if (fruit.getId() == id) {
                items.remove(fruit);
                System.out.println("Fruta eliminada: " + fruit);
                saveFruits(); // Guardar después de eliminar
                return true;
            }
        }
        return false; // Retorna false si la fruta no se encuentra
    }

    // Método para listar frutas de forma ordenada
    public void list() {
        StringBuilder output = new StringBuilder();
        output.append(String.format("%-10s | %-15s | %-10s | %-10s\n", "ID", "Nombre", "Peso (kg)", "Precio ($)"));
        output.append("----------------------------------------------------\n");

        for (Fruit fruit : items) {
            output.append(String.format("%-10d | %-15s | %-10.2f | %-10.2f\n",
                    fruit.getId(), fruit.getName(), fruit.getWeight(), fruit.getPrice()));
        }

        System.out.println(output.toString());
    }

    // Método para generar un reporte
    public void generateReport(double minWeight) {
        StringBuilder report = new StringBuilder();

        // Encabezado del reporte
        report.append("\n------ Reporte de Frutas ------\n");
        report.append("Fecha de creación: ").append(java.time.LocalDateTime.now()).append("\n");
        report.append("Peso mínimo considerado: ").append(minWeight).append(" kg\n");
        report.append(String.format("%-10s | %-15s | %-10s | %-10s\n", "ID", "Nombre", "Peso (kg)", "Precio ($)"));
        report.append("----------------------------------------------------\n");

        // Filtrar y agregar frutas al reporte
        List<Fruit> filteredFruits = new ArrayList<>();
        for (Fruit fruit : items) {
            if (fruit.getWeight() > minWeight) {
                filteredFruits.add(fruit);
                report.append(String.format("%-10d | %-15s | %-10.2f | %-10.2f\n",
                        fruit.getId(), fruit.getName(), fruit.getWeight(), fruit.getPrice()));
            }
        }

        // Manejar el caso de no encontrar frutas que cumplan el criterio
        if (filteredFruits.isEmpty()) {
            report.append("No se encontraron frutas que cumplan con el peso mínimo especificado.\n");
        }

        report.append("----------------------------------------------------\n"); // Separador para el siguiente reporte

        // Mostrar el reporte en consola y guardarlo en archivo
        System.out.println(report.toString());
        saveReportToFile(report.toString());
        appendReportToHistory(report.toString()); // Guardar en el historial
    }

    private void saveReportToFile(String reportContent) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("reporte_frutas.txt"))) {
            writer.write(reportContent);
            System.out.println("Reporte guardado en 'reporte_frutas.txt'.");
        } catch (IOException e) {
            System.err.println("Error al guardar el archivo: " + e.getMessage());
        }
    }

    private void appendReportToHistory(String reportContent) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("historial_reportes.txt", true))) {
            writer.write(reportContent);
            writer.write("\n"); // Añadir una línea en blanco entre reportes
            System.out.println("Reporte añadido al historial.");
        } catch (IOException e) {
            System.err.println("Error al guardar el historial de reportes: " + e.getMessage());
        }
    }

    // Método para mostrar el historial de reportes
    public void showReportHistory() {
        try (BufferedReader reader = new BufferedReader(new FileReader("historial_reportes.txt"))) {
            String line;
            System.out.println("\n------ Historial de Reportes ------");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo de historial de reportes.");
        } catch (IOException e) {
            System.err.println("Error al leer el historial de reportes: " + e.getMessage());
        }
    }

    // Método para guardar frutas en un archivo .dat
    private void saveFruits() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("fruits.dat"))) {
            oos.writeObject(items);
            System.out.println("Datos de frutas guardados.");
        } catch (IOException e) {
            System.err.println("Error al guardar frutas: " + e.getMessage());
        }
    }

    // Método para cargar frutas desde un archivo .dat
    @SuppressWarnings("unchecked") // Para suprimir advertencia de tipo
    private void loadFruits() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("fruits.dat"))) {
            items = (List<Fruit>) ois.readObject();
            if (!items.isEmpty()) {
                nextId = items.get(items.size() - 1).getId() + 1; // Actualiza el siguiente ID
            }
            System.out.println("Datos de frutas cargados.");
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo de frutas. Se creará un nuevo archivo.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar frutas: " + e.getMessage());
        }
    }
}