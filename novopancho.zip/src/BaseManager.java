import java.util.ArrayList;
import java.util.List;

public abstract class BaseManager<T> {
    protected List<T> items;

    public BaseManager() {
        this.items = new ArrayList<>();
    }

    protected abstract void addItemFromLine(String line);

    public List<T> getItems() {
        return items;
    }
}