import java.util.Scanner;

public class Main{
    private FruitManager fruitManager;
    private Scanner scanner;

    public Main() {
        this.fruitManager = new FruitManager();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            System.out.println("1. Crear y Guardar Fruta");
            System.out.println("2. Leer Fruta");
            System.out.println("3. Actualizar Fruta");
            System.out.println("4. Eliminar Fruta");
            System.out.println("5. Listar Frutas");
            System.out.println("6. Generar Reporte");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consumir nueva línea

            switch (option) {
                case 1:
                    System.out.print("Nombre de la fruta: ");
                    String name = scanner.nextLine();
                    System.out.print("Peso (kg): ");
                    double weight = scanner.nextDouble();
                    System.out.print("Precio ($): ");
                    double price = scanner.nextDouble();
                    fruitManager.createFruit(name, weight, price);
                    break;
                case 2:
                    System.out.print("Ingrese el ID de la fruta a leer: ");
                    int readId = scanner.nextInt();
                    Fruit fruit = fruitManager.readFruit(readId);
                    if (fruit != null) {
                        System.out.println("Fruta leída: " + fruit);
                    } else {
                        System.out.println("Fruta no encontrada.");
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el ID de la fruta a actualizar: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consumir nueva línea
                    System.out.print("Nuevo nombre de la fruta: ");
                    String newName = scanner.nextLine();
                    System.out.print("Nuevo peso (kg): ");
                    double newWeight = scanner.nextDouble();
                    System.out.print("Nuevo precio ($): ");
                    double newPrice = scanner.nextDouble();
                    if (fruitManager.updateFruit(updateId, newName, newWeight, newPrice)) {
                        System.out.println("Fruta actualizada.");
                    } else {
                        System.out.println("Fruta no encontrada.");
                    }
                    break;
                case 4:
                    System.out.print("Ingrese el ID de la fruta a eliminar: ");
                    int deleteId = scanner.nextInt();
                    if (fruitManager.deleteFruit(deleteId)) {
                        System.out.println("Fruta eliminada.");
                    } else {
                        System.out.println("Fruta no encontrada.");
                    }
                    break;
                case 5:
                    fruitManager.list();
                    break;
                case 6:
                    System.out.print("Ingrese el peso mínimo para el reporte: ");
                    double minWeightReport = scanner.nextDouble();
                    fruitManager.generateReport(minWeightReport);
                    break;
                case 7:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    public static void main(String[] args) {
        Main app = new Main();
        app.start();
    }
}